alter table CM_AST_LOC_T modify (AST_LOC_CNTCT_ID VARCHAR2(40))
/

