update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'PO' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'INV' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'CRM' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'INVW' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'CTRL' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'APP' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'CAMM' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'PRPL' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'ECD' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'DV' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'EIRT' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'PREQ' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'RCV' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'REQS' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'CM' and cur_ind=1
/

update krew_doc_typ_t set doc_search_help_url = 'default.htm?turl=WordDocuments%2Fcustomdocumentsearches.htm' where doc_typ_nm = 'KFST' and cur_ind=1
/