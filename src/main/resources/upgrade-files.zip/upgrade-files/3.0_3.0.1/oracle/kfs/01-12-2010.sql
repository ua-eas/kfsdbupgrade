update krns_parm_t set txt = 'default.htm?turl=WordDocuments%2Faccountinglineimporttemplates.htm' where nmspc_cd = 'KFS-PURAP' and parm_nm = 'LINE_ITEM_IMPORT'
/